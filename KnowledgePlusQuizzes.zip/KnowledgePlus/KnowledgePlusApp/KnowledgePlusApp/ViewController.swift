//
//  ViewController.swift
//  KnowledgePlusApp
//
//  Created by user268092 on 10/25/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func Button1(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goTo2", sender: self)    }
    
    
    @IBAction func Button2(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goTo3", sender: self)     }
    
    @IBAction func Button3(_ sender: UIButton)  {
        self.performSegue(withIdentifier: "goTo4", sender: self)     }
    
}


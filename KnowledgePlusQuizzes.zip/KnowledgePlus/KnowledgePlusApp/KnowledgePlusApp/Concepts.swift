//
//  Concepts.swift
//  KnowledgePlusApp
//
//  Created by user268092 on 10/25/24.
//

import UIKit

class Concepts: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    @IBAction func Home(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goHome", sender: self)    }

    @IBAction func Subject(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goToSubject", sender: self)    }
    
    @IBAction func Quiz(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goToQuiz", sender: self)    }
}
    

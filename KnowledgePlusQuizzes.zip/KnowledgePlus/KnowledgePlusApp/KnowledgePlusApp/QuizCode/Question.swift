//
//  Question.swift
//  Quiz
//
//  Created by Dara Aghamirkarimi on 2024-09-26.
//

import Foundation

struct Question {
    let text: String
    let answer: String
    let options: [String]
    
    init(q: String, a: String, options: [String]) {
        text = q
        answer = a
        self.options = options
    }
}

//
//  QuizBrain.swift
//  Quiz
//
//  Created by Dara Aghamirkarimi on 2024-10-04.
//

import Foundation

struct QuizBrain1{
    
    var questionNumber = 0
    var score = 0
    
    let arrayQuiz: [Question] = [
        Question(q: "What is the capital of France?", a: "Paris", options: ["Paris", "London", "Rome"]),
        Question(q: "What is 2 + 2?", a: "4", options: ["3", "4", "5"]),
        Question(q: "What is the color of the sky?", a: "Blue", options: ["Blue", "Green", "Red"]),
        Question(q: "What is the largest planet?", a: "Jupiter", options: ["Mars", "Jupiter", "Saturn"]),
        Question(q: "Which is the fastest land animal?", a: "Cheetah", options: ["Cheetah", "Lion", "Elephant"]),
        Question(q: "Which element has the chemical symbol 'O'?", a: "Oxygen", options: ["Oxygen", "Hydrogen", "Nitrogen"]),
        Question(q: "What is the tallest mountain in the world?", a: "Mount Everest", options: ["K2", "Mount Everest", "Kangchenjunga"]),
        Question(q: "Which ocean is the largest?", a: "Pacific", options: ["Atlantic", "Indian", "Pacific"]),
        Question(q: "How many continents are there?", a: "7", options: ["5", "6", "7"]),
        Question(q: "What is the hardest natural substance?", a: "Diamond", options: ["Gold", "Diamond", "Iron"])
    ]
    mutating func checkAnswer(_ userAnswer: String)->Bool{
        
        if userAnswer == arrayQuiz[questionNumber].answer {
            score += 1
            return true
            
        }else{
            return false
        }
    }
    
    mutating func nextQuestion(){
        
        if questionNumber < 9 {
            questionNumber += 1
        }else {
            questionNumber = 0
            score = 0
        }
    }
    
    func getQuestionText()->String{
        return arrayQuiz[questionNumber].text
    }
    func getProgress()-> Float{
        return Float(questionNumber+1) / Float(arrayQuiz.count)
    }
    
    func getQuestionNumber()->Int{
        return questionNumber
    }
    func getScore()->Int{
        return score
    }
    func getOptions(_ optionNumb: Int)-> String{
        return arrayQuiz[questionNumber].options[optionNumb]
    }
}

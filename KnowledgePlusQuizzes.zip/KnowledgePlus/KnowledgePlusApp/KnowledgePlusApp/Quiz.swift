//
//  Quiz.swift
//  KnowledgePlusApp
//
//  Created by user268092 on 10/25/24.
//


import UIKit

class Quiz: UIViewController {
    
    
    
    @IBOutlet weak var QuestionLabel: UILabel!
    
    @IBOutlet weak var LabelQuestionNumber: UILabel!
    @IBOutlet weak var LabelScore: UILabel!
    
    @IBOutlet weak var Option1Button: UIButton!
    @IBOutlet weak var Option2Button: UIButton!
    @IBOutlet weak var Option3Button: UIButton!
    
    @IBOutlet weak var progressBar: UIProgressView!
    
    
    var subject: String?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    
    
    var quiz = QuizBrain1()
    
    
    
    
    @IBAction func Home(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goHome", sender: self)    }
    
    @IBAction func Subject(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goToSubject", sender: self)    }
    @IBAction func Concepts(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goToConcepts", sender: self)    }
    
    
    @IBAction func AnswerButtonPressed(_ sender: UIButton) {
        
        let userAnswer = sender.configuration?.title

        
        if quiz.checkAnswer(userAnswer!){
            sender.backgroundColor = UIColor.green
        }else{
            sender.backgroundColor = UIColor.red
        }
        
        
        Timer.scheduledTimer(timeInterval:0.5 , target: self, selector: #selector(updateUI),userInfo:nil, repeats: false)
        
        quiz.nextQuestion()    }
    
    @objc func updateUI(){
        
        Option1Button.configuration?.title = quiz.getOptions(0)
        Option2Button.configuration?.title = quiz.getOptions(1)
        Option3Button.configuration?.title = quiz.getOptions(2)
        
        QuestionLabel.text = quiz.getQuestionText()
        
        Option1Button.backgroundColor = UIColor.gray
        Option2Button.backgroundColor = UIColor.gray
        Option3Button.backgroundColor = UIColor.gray
        
        progressBar.progress = quiz.getProgress()
        
        LabelQuestionNumber.text = "Question Number : \(quiz.getQuestionNumber())"
        
        LabelScore.text = "Score : \(quiz.getScore())"
    }

}

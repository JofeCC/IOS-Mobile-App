//
//  ViewController3.swift
//  KnowledgePlusApp
//
//  Created by user268092 on 10/25/24.
//

import UIKit

class ViewController3: UIViewController {
    
    var subject: String?
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func Home(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)    }
    
    
    @IBAction func Concepts(_ sender: UIButton) {
        self.performSegue(withIdentifier: "goFrom3ToConcepts", sender: self)    }
    
    @IBAction func Quiz(_ sender: UIButton)  {
        subject = "3"
        self.performSegue(withIdentifier: "goToQuiz", sender: self)    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let destinationVC = segue.destination as? Quiz{
            if segue.identifier == "goToQuiz" {
                destinationVC.subject = subject
            }
        }
    }}

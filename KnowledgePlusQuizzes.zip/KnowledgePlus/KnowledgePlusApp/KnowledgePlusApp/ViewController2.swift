//
//  ViewController2.swift
//  KnowledgePlusApp
//
//  Created by user268092 on 10/25/24.
//

import UIKit

class ViewController2: UIViewController {

    @IBOutlet weak var label: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    

    @IBAction func Home(_ sender: UIButton) {
        self.dismiss(animated: true, completion: nil)    }
}

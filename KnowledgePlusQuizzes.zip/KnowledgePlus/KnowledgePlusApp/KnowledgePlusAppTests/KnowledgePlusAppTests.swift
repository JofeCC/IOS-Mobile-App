//
//  KnowledgePlusAppTests.swift
//  KnowledgePlusAppTests
//
//  Created by user268092 on 10/25/24.
//

import Testing
@testable import KnowledgePlusApp

struct KnowledgePlusAppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
